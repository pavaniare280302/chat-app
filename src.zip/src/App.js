import React, { useState } from 'react';
import './App.css';

const user_list = ["Alan", "Bob", "Carol", "Dean", "Elin"];

const App = () => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);

  const handleInputChange = (event) => {
    setMessage(event.target.value);
  };

  const handleSendClick = () => {
    if (message.trim() !== '') {
      const randomUser = user_list[Math.floor(Math.random() * user_list.length)];
      const newMessage = {
        user: randomUser,
        content: message,
        likes: 0
      };

      setMessages([...messages, newMessage]);
      setMessage('');
    }
  };

  const handleLikeClick = (index) => {
    setMessages(prevMessages => {
      const updatedMessages = [...prevMessages];
      updatedMessages[index].likes += 1;
      return updatedMessages;
    });
  };

  return (
    <div className="chat-container">
      <div className="message-thread">
        {messages.map((message, index) => (
          <div key={index} className="message">
            <div className="message-content">{message.content}</div>
            <div className="message-details">
              <div className="message-username">{message.user}</div>
              <div className="message-likes">
                <button onClick={() => handleLikeClick(index)}>
                  Like
                </button>
                <span>{message.likes}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="chat-input">
        <input
          type="text"
          value={message}
          onChange={handleInputChange}
          placeholder="Type your message"
        />
        <button onClick={handleSendClick}>Send</button>
      </div>
    </div>
  );
};

export default App;
